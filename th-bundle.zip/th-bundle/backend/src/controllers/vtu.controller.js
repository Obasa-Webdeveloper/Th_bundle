const { v4: uuidv4 } = require('uuid');
const { WalletService } = require('../services/wallet.service');
const ProviderManager = require('../services/providers/ProviderManager');
const DataPlan = require('../models/DataPlan');
const DataPurchase = require('../models/DataPurchase');
const logger = require('../utils/logger');

/**
 * POST /api/v1/vtu/data/purchase
 * Debits wallet first (reserves funds), then attempts the purchase across
 * all enabled providers in priority order. On total failure, auto-refunds.
 */
async function purchaseData(req, res, next) {
  const userId = req.user.id;
  const { network, plan_id: planId, phone } = req.body;
  const reference = `THB-${Date.now()}-${uuidv4().slice(0, 8)}`;

  try {
    const plan = await DataPlan.findByPk(planId);
    if (!plan || !plan.isEnabled) {
      return res.status(404).json({ success: false, message: 'Data plan not found or disabled' });
    }

    const { wallet, transaction: walletTx } = await WalletService.debit({
      userId,
      amount: plan.sellingPrice,
      source: 'purchase',
      reference,
      meta: { service: 'data', network, planId },
    });

    const purchase = await DataPurchase.create({
      userId,
      walletTxId: walletTx.id,
      network,
      planId,
      phone,
      amount: plan.sellingPrice,
      status: 'pending',
    });

    try {
      const result = await ProviderManager.execute('data', 'purchaseData', {
        network,
        planCode: plan.planCode,
        phone,
        amount: plan.sellingPrice,
        reference,
      });

      purchase.status = 'success';
      purchase.providerId = result.providerId;
      purchase.providerReference = result.providerReference;
      await purchase.save();
      await WalletService.markSuccess(walletTx.id);

      return res.json({
        success: true,
        message: 'Data purchase successful',
        data: {
          transaction_id: purchase.id,
          reference,
          status: 'success',
          amount: plan.sellingPrice,
          wallet_balance_after: wallet.balance,
        },
      });
    } catch (providerErr) {
      // All providers failed -> refund automatically.
      logger.error(`Data purchase failed for all providers: ${providerErr.message}`);
      purchase.status = 'failed';
      await purchase.save();
      await WalletService.reverse(walletTx.id, providerErr.message);

      return res.status(503).json({
        success: false,
        message: 'All data providers are currently unavailable. You have been refunded.',
        data: { transaction_id: purchase.id, reference, status: 'failed', refunded: true },
      });
    }
  } catch (err) {
    next(err);
  }
}

module.exports = { purchaseData };
