const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const sequelize = require('../config/db');
const User = require('../models/User');
const { Wallet } = require('../models/Wallet');
const Otp = require('../models/Otp');
const otpService = require('../services/otp.service');

function generateReferralCode() {
  return `TH-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function signTokens(user) {
  const accessToken = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m',
  });
  const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES || '30d',
  });
  return { accessToken, refreshToken };
}

async function register(req, res, next) {
  const { full_name: fullName, email, phone, password, referral_code: referralCode } = req.body;
  const t = await sequelize.transaction();
  try {
    const existing = await User.unscoped().findOne({ where: { [require('sequelize').Op.or]: [{ email }, { phone }] } });
    if (existing) {
      await t.rollback();
      return res.status(409).json({ success: false, message: 'Email or phone already registered' });
    }

    let referredBy = null;
    if (referralCode) {
      const referrer = await User.findOne({ where: { referralCode } });
      if (referrer) referredBy = referrer.id;
    }

    const passwordHash = await bcrypt.hash(password, Number(process.env.BCRYPT_ROUNDS || 12));
    const user = await User.create({
      fullName,
      email,
      phone,
      passwordHash,
      referralCode: generateReferralCode(),
      referredBy,
    }, { transaction: t });

    await Wallet.create({ userId: user.id }, { transaction: t });
    await t.commit();

    await otpService.sendOtp({ userId: user.id, destination: email, channel: 'email', purpose: 'verify_email' });
    await otpService.sendOtp({ userId: user.id, destination: phone, channel: 'sms', purpose: 'verify_phone' });

    return res.status(201).json({
      success: true,
      message: 'Registration successful. Please verify your email and phone.',
      data: { id: user.id, email: user.email, phone: user.phone },
    });
  } catch (err) {
    await t.rollback();
    next(err);
  }
}

async function login(req, res, next) {
  const { email, password } = req.body;
  try {
    const user = await User.unscoped().findOne({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
    if (user.isBlacklisted || !user.isActive) {
      return res.status(403).json({ success: false, message: 'Account suspended. Contact support.' });
    }
    if (user.twoFactorEnabled) {
      return res.json({ success: true, message: '2FA required', data: { requires2fa: true, userId: user.id } });
    }

    user.lastLoginAt = new Date();
    await user.save();

    const tokens = signTokens(user);
    return res.json({
      success: true,
      message: 'Login successful',
      data: { ...tokens, user: { id: user.id, fullName: user.fullName, email: user.email } },
    });
  } catch (err) {
    next(err);
  }
}

async function verifyOtp(req, res, next) {
  const { destination, code, purpose } = req.body;
  try {
    const result = await otpService.verifyOtp({ destination, code, purpose });
    if (!result.valid) {
      return res.status(400).json({ success: false, message: result.reason || 'Invalid or expired OTP' });
    }

    if (purpose === 'verify_email') {
      await User.update({ emailVerifiedAt: new Date() }, { where: { id: result.userId } });
    } else if (purpose === 'verify_phone') {
      await User.update({ phoneVerifiedAt: new Date() }, { where: { id: result.userId } });
    }

    return res.json({ success: true, message: 'OTP verified successfully' });
  } catch (err) {
    next(err);
  }
}

async function refreshToken(req, res, next) {
  const { refresh_token: token } = req.body;
  try {
    const payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
    const user = await User.findByPk(payload.id);
    if (!user) return res.status(401).json({ success: false, message: 'Invalid refresh token' });
    const tokens = signTokens(user);
    return res.json({ success: true, data: tokens });
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired refresh token' });
  }
}

module.exports = { register, login, verifyOtp, refreshToken };
