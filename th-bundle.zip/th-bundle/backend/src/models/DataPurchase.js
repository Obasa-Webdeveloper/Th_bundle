const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const DataPurchase = sequelize.define('DataPurchase', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID, allowNull: false, field: 'user_id' },
  walletTxId: { type: DataTypes.UUID, field: 'wallet_tx_id' },
  network: { type: DataTypes.STRING(20), allowNull: false },
  planId: { type: DataTypes.UUID, field: 'plan_id' },
  phone: { type: DataTypes.STRING(20), allowNull: false },
  amount: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  providerId: { type: DataTypes.UUID, field: 'provider_id' },
  providerReference: { type: DataTypes.STRING(100), field: 'provider_reference' },
  status: { type: DataTypes.ENUM('pending', 'success', 'failed', 'reversed'), defaultValue: 'pending' },
}, { tableName: 'data_purchases', updatedAt: false });

module.exports = DataPurchase;
