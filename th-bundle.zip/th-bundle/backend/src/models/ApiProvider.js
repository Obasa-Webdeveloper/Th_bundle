const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

// Admin-configurable VTU/payment providers. Adding a new provider,
// disabling one, or re-ordering failover priority is a DB write from
// the admin dashboard — no code deploy required.
const ApiProvider = sequelize.define('ApiProvider', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  category: { type: DataTypes.ENUM('vtu', 'payment'), allowNull: false },
  services: { type: DataTypes.ARRAY(DataTypes.STRING), allowNull: false, defaultValue: [] },
  baseUrl: { type: DataTypes.TEXT, allowNull: false, field: 'base_url' },
  apiKey: { type: DataTypes.TEXT, field: 'api_key' },
  secretKey: { type: DataTypes.TEXT, field: 'secret_key' },
  priority: { type: DataTypes.INTEGER, defaultValue: 1 },
  isEnabled: { type: DataTypes.BOOLEAN, defaultValue: true, field: 'is_enabled' },
  config: { type: DataTypes.JSONB, defaultValue: {} },
}, { tableName: 'api_providers' });

module.exports = ApiProvider;
