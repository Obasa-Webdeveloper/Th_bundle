const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const DataPlan = sequelize.define('DataPlan', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  network: { type: DataTypes.STRING(20), allowNull: false },
  planName: { type: DataTypes.STRING(100), allowNull: false, field: 'plan_name' },
  planCode: { type: DataTypes.STRING(50), allowNull: false, field: 'plan_code' },
  validity: { type: DataTypes.STRING(30) },
  costPrice: { type: DataTypes.DECIMAL(10, 2), allowNull: false, field: 'cost_price' },
  sellingPrice: { type: DataTypes.DECIMAL(10, 2), allowNull: false, field: 'selling_price' },
  providerId: { type: DataTypes.UUID, field: 'provider_id' },
  isEnabled: { type: DataTypes.BOOLEAN, defaultValue: true, field: 'is_enabled' },
}, { tableName: 'data_plans', updatedAt: false });

module.exports = DataPlan;
