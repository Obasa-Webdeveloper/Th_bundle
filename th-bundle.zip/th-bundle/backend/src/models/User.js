const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  fullName: { type: DataTypes.STRING(150), allowNull: false, field: 'full_name' },
  email: { type: DataTypes.STRING(150), allowNull: false, unique: true, validate: { isEmail: true } },
  phone: { type: DataTypes.STRING(20), allowNull: false, unique: true },
  passwordHash: { type: DataTypes.STRING(255), allowNull: false, field: 'password_hash' },
  referralCode: { type: DataTypes.STRING(20), allowNull: false, unique: true, field: 'referral_code' },
  referredBy: { type: DataTypes.UUID, field: 'referred_by' },
  emailVerifiedAt: { type: DataTypes.DATE, field: 'email_verified_at' },
  phoneVerifiedAt: { type: DataTypes.DATE, field: 'phone_verified_at' },
  twoFactorEnabled: { type: DataTypes.BOOLEAN, defaultValue: false, field: 'two_factor_enabled' },
  twoFactorSecret: { type: DataTypes.STRING(255), field: 'two_factor_secret' },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true, field: 'is_active' },
  isBlacklisted: { type: DataTypes.BOOLEAN, defaultValue: false, field: 'is_blacklisted' },
  pinHash: { type: DataTypes.STRING(255), field: 'pin_hash' },
  avatarUrl: { type: DataTypes.TEXT, field: 'avatar_url' },
  lastLoginAt: { type: DataTypes.DATE, field: 'last_login_at' },
}, {
  tableName: 'users',
  defaultScope: { attributes: { exclude: ['passwordHash', 'pinHash', 'twoFactorSecret'] } },
  scopes: { withSecrets: { attributes: {} } },
});

module.exports = User;
