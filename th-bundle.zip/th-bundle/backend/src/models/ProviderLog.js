const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const ProviderLog = sequelize.define('ProviderLog', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  providerId: { type: DataTypes.UUID, field: 'provider_id' },
  requestType: { type: DataTypes.STRING(30), field: 'request_type' },
  requestPayload: { type: DataTypes.JSONB, field: 'request_payload' },
  responsePayload: { type: DataTypes.JSONB, field: 'response_payload' },
  statusCode: { type: DataTypes.INTEGER, field: 'status_code' },
  success: { type: DataTypes.BOOLEAN },
  durationMs: { type: DataTypes.INTEGER, field: 'duration_ms' },
}, { tableName: 'provider_logs', updatedAt: false });

module.exports = ProviderLog;
