const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Otp = sequelize.define('Otp', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID, field: 'user_id' },
  destination: { type: DataTypes.STRING(150), allowNull: false },
  channel: { type: DataTypes.ENUM('email', 'sms'), allowNull: false },
  purpose: { type: DataTypes.ENUM('verify_email', 'verify_phone', 'reset_password', '2fa'), allowNull: false },
  codeHash: { type: DataTypes.STRING(255), allowNull: false, field: 'code_hash' },
  expiresAt: { type: DataTypes.DATE, allowNull: false, field: 'expires_at' },
  consumedAt: { type: DataTypes.DATE, field: 'consumed_at' },
  attempts: { type: DataTypes.INTEGER, defaultValue: 0 },
}, { tableName: 'otps', updatedAt: false });

module.exports = Otp;
