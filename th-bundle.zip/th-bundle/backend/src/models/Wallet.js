const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const User = require('./User');

const Wallet = sequelize.define('Wallet', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID, allowNull: false, unique: true, field: 'user_id' },
  balance: { type: DataTypes.DECIMAL(14, 2), defaultValue: 0 },
  bonusBalance: { type: DataTypes.DECIMAL(14, 2), defaultValue: 0, field: 'bonus_balance' },
  virtualAccountNumber: { type: DataTypes.STRING(20), field: 'virtual_account_number' },
  virtualAccountBank: { type: DataTypes.STRING(100), field: 'virtual_account_bank' },
  virtualAccountProvider: { type: DataTypes.STRING(50), field: 'virtual_account_provider' },
  isLocked: { type: DataTypes.BOOLEAN, defaultValue: false, field: 'is_locked' },
}, { tableName: 'wallets' });

const WalletTransaction = sequelize.define('WalletTransaction', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  walletId: { type: DataTypes.UUID, allowNull: false, field: 'wallet_id' },
  reference: { type: DataTypes.STRING(64), allowNull: false, unique: true },
  type: { type: DataTypes.ENUM('credit', 'debit'), allowNull: false },
  source: {
    type: DataTypes.ENUM('funding', 'purchase', 'refund', 'referral_bonus', 'cashback', 'admin_adjustment'),
    allowNull: false,
  },
  amount: { type: DataTypes.DECIMAL(14, 2), allowNull: false },
  balanceBefore: { type: DataTypes.DECIMAL(14, 2), allowNull: false, field: 'balance_before' },
  balanceAfter: { type: DataTypes.DECIMAL(14, 2), allowNull: false, field: 'balance_after' },
  status: { type: DataTypes.ENUM('pending', 'success', 'failed', 'reversed'), defaultValue: 'pending' },
  meta: { type: DataTypes.JSONB },
}, { tableName: 'wallet_transactions' });

User.hasOne(Wallet, { foreignKey: 'userId' });
Wallet.belongsTo(User, { foreignKey: 'userId' });
Wallet.hasMany(WalletTransaction, { foreignKey: 'walletId' });
WalletTransaction.belongsTo(Wallet, { foreignKey: 'walletId' });

module.exports = { Wallet, WalletTransaction };
