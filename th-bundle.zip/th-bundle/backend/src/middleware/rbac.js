/**
 * requirePermission('wallet.manual_fund') -> 403 unless the admin's role
 * has that permission code. Permissions are loaded onto req.admin.permissions
 * at login time (see admin auth controller) so this stays a fast in-memory check.
 */
function requirePermission(permissionCode) {
  return (req, res, next) => {
    const perms = req.admin?.permissions || [];
    if (!perms.includes(permissionCode) && !perms.includes('*')) {
      return res.status(403).json({ success: false, message: `Missing permission: ${permissionCode}` });
    }
    next();
  };
}

module.exports = { requirePermission };
