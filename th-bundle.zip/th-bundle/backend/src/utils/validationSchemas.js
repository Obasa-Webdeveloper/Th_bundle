const Joi = require('joi');

const registerSchema = Joi.object({
  full_name: Joi.string().min(3).max(150).required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^0[789][01]\d{8}$/).required().messages({
    'string.pattern.base': 'Phone must be a valid Nigerian number, e.g. 08012345678',
  }),
  password: Joi.string().min(8).required(),
  referral_code: Joi.string().optional().allow('', null),
});

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

const verifyOtpSchema = Joi.object({
  destination: Joi.string().required(),
  code: Joi.string().length(6).required(),
  purpose: Joi.string().valid('verify_email', 'verify_phone', 'reset_password', '2fa').required(),
});

const purchaseDataSchema = Joi.object({
  network: Joi.string().valid('MTN', 'AIRTEL', 'GLO', '9MOBILE').required(),
  plan_id: Joi.string().uuid().required(),
  phone: Joi.string().pattern(/^0[789][01]\d{8}$/).required(),
  coupon_code: Joi.string().optional().allow('', null),
});

const purchaseAirtimeSchema = Joi.object({
  network: Joi.string().valid('MTN', 'AIRTEL', 'GLO', '9MOBILE').required(),
  phone: Joi.string().pattern(/^0[789][01]\d{8}$/).required(),
  amount: Joi.number().min(50).max(50000).required(),
  coupon_code: Joi.string().optional().allow('', null),
});

const fundWalletSchema = Joi.object({
  amount: Joi.number().min(100).required(),
  gateway: Joi.string().valid('paystack', 'flutterwave', 'monnify').required(),
});

module.exports = {
  registerSchema,
  loginSchema,
  verifyOtpSchema,
  purchaseDataSchema,
  purchaseAirtimeSchema,
  fundWalletSchema,
};
