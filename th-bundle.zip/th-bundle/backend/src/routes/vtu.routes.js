const router = require('express').Router();
const vtuController = require('../controllers/vtu.controller');
const { authenticate } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { purchaseDataSchema } = require('../utils/validationSchemas');

router.use(authenticate);
router.post('/data/purchase', validate(purchaseDataSchema), vtuController.purchaseData);
// router.get('/data/plans', vtuController.listDataPlans);
// router.post('/airtime/purchase', validate(purchaseAirtimeSchema), vtuController.purchaseAirtime);

module.exports = router;
