const router = require('express').Router();

router.use('/auth', require('./auth.routes'));
router.use('/vtu', require('./vtu.routes'));
// router.use('/wallet', require('./wallet.routes'));
// router.use('/bills', require('./bills.routes'));
// router.use('/users', require('./users.routes'));
// router.use('/referrals', require('./referrals.routes'));
// router.use('/coupons', require('./coupons.routes'));
// router.use('/notifications', require('./notifications.routes'));
// router.use('/support', require('./support.routes'));
// router.use('/webhooks', require('./webhooks.routes'));
// router.use('/admin', require('./admin/index.routes'));

router.get('/health', (req, res) => res.json({ success: true, message: 'T&H BUNDLE API is running' }));

module.exports = router;
