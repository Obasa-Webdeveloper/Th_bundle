const { v4: uuidv4 } = require('uuid');
const sequelize = require('../config/db');
const { Wallet, WalletTransaction } = require('../models/Wallet');

class InsufficientBalanceError extends Error {
  constructor() {
    super('Insufficient wallet balance');
    this.statusCode = 422;
  }
}

class WalletService {
  /**
   * Debit a wallet inside a row-locked DB transaction so concurrent
   * requests can never double-spend the same balance.
   */
  static async debit({ userId, amount, source, meta = {}, reference = uuidv4() }) {
    return sequelize.transaction(async (t) => {
      const wallet = await Wallet.findOne({ where: { userId }, lock: t.LOCK.UPDATE, transaction: t });
      if (!wallet) throw Object.assign(new Error('Wallet not found'), { statusCode: 404 });
      if (wallet.isLocked) throw Object.assign(new Error('Wallet is locked'), { statusCode: 403 });
      if (Number(wallet.balance) < Number(amount)) throw new InsufficientBalanceError();

      const balanceBefore = wallet.balance;
      const balanceAfter = Number(wallet.balance) - Number(amount);
      wallet.balance = balanceAfter;
      await wallet.save({ transaction: t });

      const tx = await WalletTransaction.create({
        walletId: wallet.id,
        reference,
        type: 'debit',
        source,
        amount,
        balanceBefore,
        balanceAfter,
        status: 'pending', // flipped to success/failed/reversed once provider call resolves
        meta,
      }, { transaction: t });

      return { wallet, transaction: tx };
    });
  }

  static async credit({ userId, amount, source, meta = {}, reference = uuidv4() }) {
    return sequelize.transaction(async (t) => {
      const wallet = await Wallet.findOne({ where: { userId }, lock: t.LOCK.UPDATE, transaction: t });
      if (!wallet) throw Object.assign(new Error('Wallet not found'), { statusCode: 404 });

      const balanceBefore = wallet.balance;
      const balanceAfter = Number(wallet.balance) + Number(amount);
      wallet.balance = balanceAfter;
      await wallet.save({ transaction: t });

      const tx = await WalletTransaction.create({
        walletId: wallet.id,
        reference,
        type: 'credit',
        source,
        amount,
        balanceBefore,
        balanceAfter,
        status: 'success',
        meta,
      }, { transaction: t });

      return { wallet, transaction: tx };
    });
  }

  /** Mark a pending debit as settled (provider purchase succeeded). */
  static async markSuccess(walletTransactionId) {
    await WalletTransaction.update({ status: 'success' }, { where: { id: walletTransactionId } });
  }

  /**
   * Provider purchase failed after all failovers exhausted: refund the
   * user automatically and mark the original debit as reversed.
   */
  static async reverse(walletTransactionId, reason) {
    return sequelize.transaction(async (t) => {
      const original = await WalletTransaction.findByPk(walletTransactionId, { transaction: t, lock: t.LOCK.UPDATE });
      if (!original || original.status === 'reversed') return;

      const wallet = await Wallet.findByPk(original.walletId, { transaction: t, lock: t.LOCK.UPDATE });
      const balanceBefore = wallet.balance;
      const balanceAfter = Number(wallet.balance) + Number(original.amount);
      wallet.balance = balanceAfter;
      await wallet.save({ transaction: t });

      await WalletTransaction.create({
        walletId: wallet.id,
        reference: `${original.reference}-refund`,
        type: 'credit',
        source: 'refund',
        amount: original.amount,
        balanceBefore,
        balanceAfter,
        status: 'success',
        meta: { originalTransactionId: original.id, reason },
      }, { transaction: t });

      original.status = 'reversed';
      await original.save({ transaction: t });
    });
  }
}

module.exports = { WalletService, InsufficientBalanceError };
