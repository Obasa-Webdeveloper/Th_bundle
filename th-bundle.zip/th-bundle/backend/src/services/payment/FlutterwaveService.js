const axios = require('axios');
const crypto = require('crypto');

const client = axios.create({
  baseURL: 'https://api.flutterwave.com/v3',
  headers: { Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}` },
});

class FlutterwaveService {
  static async initiate({ email, amount, reference, redirectUrl, name }) {
    const { data } = await client.post('/payments', {
      tx_ref: reference,
      amount,
      currency: 'NGN',
      redirect_url: redirectUrl,
      customer: { email, name },
    });
    return data.data; // { link }
  }

  static async verify(transactionId) {
    const { data } = await client.get(`/transactions/${transactionId}/verify`);
    return data.data;
  }

  /** Create a static virtual account number for a customer. */
  static async createVirtualAccount({ email, bvn, txRef, isPermanent = true }) {
    const { data } = await client.post('/virtual-account-numbers', {
      email,
      bvn,
      tx_ref: txRef,
      is_permanent: isPermanent,
    });
    return data.data;
  }

  /** Flutterwave sends a `verif-hash` header matching a secret hash you configure on the dashboard. */
  static verifyWebhookSignature(signatureHeader) {
    return signatureHeader === process.env.FLUTTERWAVE_WEBHOOK_HASH;
  }
}

module.exports = FlutterwaveService;
