const axios = require('axios');
const crypto = require('crypto');

const client = axios.create({
  baseURL: 'https://api.paystack.co',
  headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` },
});

class PaystackService {
  /** Initialize a checkout transaction; returns authorization_url + reference. */
  static async initiate({ email, amountKobo, reference, callbackUrl }) {
    const { data } = await client.post('/transaction/initialize', {
      email,
      amount: amountKobo,
      reference,
      callback_url: callbackUrl,
    });
    return data.data; // { authorization_url, access_code, reference }
  }

  static async verify(reference) {
    const { data } = await client.get(`/transaction/verify/${reference}`);
    return data.data; // { status: 'success'|..., amount, currency, ... }
  }

  /** Create a Dedicated Virtual Account for a customer (wallet funding via bank transfer). */
  static async createDedicatedAccount({ customerCode, preferredBank = 'wema-bank' }) {
    const { data } = await client.post('/dedicated_account', {
      customer: customerCode,
      preferred_bank: preferredBank,
    });
    return data.data;
  }

  static async createCustomer({ email, firstName, lastName, phone }) {
    const { data } = await client.post('/customer', {
      email, first_name: firstName, last_name: lastName, phone,
    });
    return data.data;
  }

  /** Verify webhook signature per Paystack docs. */
  static verifyWebhookSignature(rawBody, signatureHeader) {
    const hash = crypto
      .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
      .update(rawBody)
      .digest('hex');
    return hash === signatureHeader;
  }
}

module.exports = PaystackService;
