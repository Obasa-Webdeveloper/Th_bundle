const ApiProvider = require('../../models/ApiProvider');
const logger = require('../../utils/logger');

const VtpassAdapter = require('./VtpassAdapter');
// const ClubkonnectAdapter = require('./ClubkonnectAdapter');
// const GsubzAdapter = require('./GsubzAdapter');

// Map a provider's "config.driver" field to its adapter class. To add a
// brand-new provider integration: write an Adapter class implementing
// BaseVtuAdapter, register it here, then create the provider row from
// the admin dashboard with config.driver = 'clubkonnect' (etc). No other
// code changes are needed.
const ADAPTER_REGISTRY = {
  vtpass: VtpassAdapter,
  // clubkonnect: ClubkonnectAdapter,
  // gsubz: GsubzAdapter,
};

class ProviderManager {
  /**
   * Get enabled providers supporting `service`, ordered by priority (ascending = tried first).
   */
  static async getProvidersForService(service) {
    const providers = await ApiProvider.findAll({
      where: { category: 'vtu', isEnabled: true },
      order: [['priority', 'ASC']],
    });
    return providers.filter((p) => p.services.includes(service));
  }

  static buildAdapter(providerRecord) {
    const driver = providerRecord.config?.driver;
    const AdapterClass = ADAPTER_REGISTRY[driver];
    if (!AdapterClass) {
      throw new Error(`No adapter registered for driver "${driver}" (provider: ${providerRecord.name})`);
    }
    return new AdapterClass(providerRecord);
  }

  /**
   * Execute `methodName` (e.g. 'purchaseData') against the first available
   * provider for `service`, automatically falling over to the next
   * enabled provider (by priority) if one fails or times out.
   *
   * @returns {{success, providerId, providerReference, raw, attempts}}
   */
  static async execute(service, methodName, payload) {
    const providers = await ProviderManager.getProvidersForService(service);
    if (providers.length === 0) {
      const err = new Error(`No enabled provider configured for service "${service}"`);
      err.statusCode = 503;
      throw err;
    }

    const attempts = [];
    for (const providerRecord of providers) {
      const startedAt = Date.now();
      try {
        const adapter = ProviderManager.buildAdapter(providerRecord);
        const result = await adapter[methodName](payload);
        const durationMs = Date.now() - startedAt;

        await ProviderManager.logAttempt(providerRecord.id, methodName, payload, result.raw, true, durationMs);
        attempts.push({ providerId: providerRecord.id, success: result.success, durationMs });

        if (result.success) {
          return { ...result, providerId: providerRecord.id, attempts };
        }
        // Provider responded but reported failure -> try next provider.
        logger.warn(`Provider ${providerRecord.name} reported failure for ${methodName}`, { raw: result.raw });
      } catch (err) {
        const durationMs = Date.now() - startedAt;
        await ProviderManager.logAttempt(providerRecord.id, methodName, payload, { error: err.message }, false, durationMs);
        attempts.push({ providerId: providerRecord.id, success: false, error: err.message, durationMs });
        logger.error(`Provider ${providerRecord.name} threw error for ${methodName}: ${err.message}`);
        // continue to next provider (failover)
      }
    }

    const err = new Error(`All providers failed for service "${service}" / method "${methodName}"`);
    err.statusCode = 503;
    err.attempts = attempts;
    throw err;
  }

  static async logAttempt(providerId, requestType, requestPayload, responsePayload, success, durationMs) {
    const ProviderLog = require('../../models/ProviderLog');
    try {
      await ProviderLog.create({
        providerId,
        requestType,
        requestPayload,
        responsePayload,
        success,
        durationMs,
      });
    } catch (e) {
      logger.error(`Failed to write provider log: ${e.message}`);
    }
  }
}

module.exports = ProviderManager;
