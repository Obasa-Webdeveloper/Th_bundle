const axios = require('axios');
const BaseVtuAdapter = require('./BaseVtuAdapter');

/**
 * Example concrete adapter for a VTpass-style REST API.
 * Swap in real endpoint paths/params per the provider's docs.
 * All config (baseUrl, apiKey, secretKey) comes from the `api_providers`
 * DB row, editable from the admin dashboard.
 */
class VtpassAdapter extends BaseVtuAdapter {
  constructor(providerRecord) {
    super(providerRecord);
    this.client = axios.create({
      baseURL: providerRecord.baseUrl,
      timeout: 15000,
      headers: {
        'api-key': providerRecord.apiKey,
        'secret-key': providerRecord.secretKey,
        'Content-Type': 'application/json',
      },
    });
  }

  async purchaseData({ network, planCode, phone, amount, reference }) {
    const { data } = await this.client.post('/pay', {
      request_id: reference,
      serviceID: `${network.toLowerCase()}-data`,
      billersCode: phone,
      variation_code: planCode,
      phone,
      amount,
    });
    const success = data?.code === '000';
    return { success, providerReference: data?.requestId || reference, raw: data };
  }

  async purchaseAirtime({ network, phone, amount, reference }) {
    const { data } = await this.client.post('/pay', {
      request_id: reference,
      serviceID: network.toLowerCase(),
      amount,
      phone,
    });
    const success = data?.code === '000';
    return { success, providerReference: data?.requestId || reference, raw: data };
  }

  async verifySmartcard({ provider, smartcardNumber }) {
    const { data } = await this.client.post('/merchant-verify', {
      billersCode: smartcardNumber,
      serviceID: provider.toLowerCase(),
    });
    return { success: !!data?.content?.Customer_Name, customerName: data?.content?.Customer_Name, raw: data };
  }

  async checkTransactionStatus(reference) {
    const { data } = await this.client.post('/requery', { request_id: reference });
    return { success: data?.code === '000', raw: data };
  }
}

module.exports = VtpassAdapter;
