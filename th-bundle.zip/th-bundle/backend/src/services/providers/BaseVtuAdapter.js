/**
 * BaseVtuAdapter
 * ----------------
 * Every VTU provider integration (VTpass, Clubkonnect, Gsubz, a custom
 * provider, etc.) must extend this class and implement its methods.
 * The ProviderManager only ever talks to this interface, so swapping
 * or adding providers never touches business logic in the controllers.
 */
class BaseVtuAdapter {
  constructor(providerRecord) {
    this.provider = providerRecord; // Sequelize ApiProvider row (baseUrl, apiKey, config, etc.)
  }

  /** @returns {Promise<{success:boolean, providerReference:string, raw:object}>} */
  async purchaseData(/* { network, planCode, phone, amount } */) {
    throw new Error('purchaseData() not implemented');
  }

  async purchaseAirtime(/* { network, phone, amount } */) {
    throw new Error('purchaseAirtime() not implemented');
  }

  async verifySmartcard(/* { provider, smartcardNumber } */) {
    throw new Error('verifySmartcard() not implemented');
  }

  async subscribeCable(/* { provider, smartcardNumber, packageCode } */) {
    throw new Error('subscribeCable() not implemented');
  }

  async verifyMeter(/* { disco, meterNumber, meterType } */) {
    throw new Error('verifyMeter() not implemented');
  }

  async payElectricity(/* { disco, meterNumber, meterType, amount } */) {
    throw new Error('payElectricity() not implemented');
  }

  async purchaseEducationPin(/* { examType, quantity } */) {
    throw new Error('purchaseEducationPin() not implemented');
  }

  async checkTransactionStatus(/* providerReference */) {
    throw new Error('checkTransactionStatus() not implemented');
  }
}

module.exports = BaseVtuAdapter;
