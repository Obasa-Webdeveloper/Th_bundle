const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const Otp = require('../models/Otp');
const logger = require('../utils/logger');
// const mailer = require('./mailer.service');
// const sms = require('./sms.service');

function generateCode() {
  return crypto.randomInt(100000, 999999).toString();
}

class OtpService {
  static async sendOtp({ userId, destination, channel, purpose }) {
    const code = generateCode();
    const codeHash = await bcrypt.hash(code, 10);
    const expiresAt = new Date(Date.now() + Number(process.env.OTP_EXPIRY_MINUTES || 10) * 60 * 1000);

    await Otp.create({ userId, destination, channel, purpose, codeHash, expiresAt });

    // Dispatch via the appropriate channel. Swapped out for real
    // mailer/SMS gateway integrations in production.
    if (channel === 'email') {
      logger.info(`[MOCK EMAIL] OTP ${code} to ${destination} (${purpose})`);
      // await mailer.send({ to: destination, subject: 'Your T&H BUNDLE OTP', text: `Your code is ${code}` });
    } else {
      logger.info(`[MOCK SMS] OTP ${code} to ${destination} (${purpose})`);
      // await sms.send({ to: destination, message: `Your T&H BUNDLE code is ${code}` });
    }

    return { sent: true };
  }

  static async verifyOtp({ destination, code, purpose }) {
    const otp = await Otp.findOne({
      where: { destination, purpose, consumedAt: null },
      order: [['createdAt', 'DESC']],
    });
    if (!otp) return { valid: false, reason: 'No OTP request found' };
    if (otp.expiresAt < new Date()) return { valid: false, reason: 'OTP expired' };
    if (otp.attempts >= 5) return { valid: false, reason: 'Too many attempts, request a new OTP' };

    const match = await bcrypt.compare(code, otp.codeHash);
    if (!match) {
      otp.attempts += 1;
      await otp.save();
      return { valid: false, reason: 'Incorrect OTP' };
    }

    otp.consumedAt = new Date();
    await otp.save();
    return { valid: true, userId: otp.userId };
  }
}

module.exports = OtpService;
