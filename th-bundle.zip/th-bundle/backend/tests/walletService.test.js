/**
 * Unit test example for WalletService.debit insufficient-balance guard.
 * In a full suite this would mock Sequelize with sequelize-mock or a
 * dedicated test DB + transactions rolled back after each test.
 */
const { InsufficientBalanceError } = require('../src/services/wallet.service');

describe('InsufficientBalanceError', () => {
  it('has HTTP 422 status code', () => {
    const err = new InsufficientBalanceError();
    expect(err.statusCode).toBe(422);
    expect(err.message).toMatch(/insufficient/i);
  });
});
