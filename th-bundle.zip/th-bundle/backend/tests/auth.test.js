/**
 * Sample integration test. Run with: npm test
 * Assumes a test database is configured via .env.test (see DEPLOYMENT.md).
 */
const request = require('supertest');
const app = require('../src/server');

describe('Auth API', () => {
  it('rejects registration with an invalid phone number', async () => {
    const res = await request(app).post('/api/v1/auth/register').send({
      full_name: 'Test User',
      email: 'test@example.com',
      phone: '12345',
      password: 'Str0ngP@ssw0rd',
    });
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
  });

  it('rejects login with wrong credentials', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({
      email: 'nonexistent@example.com',
      password: 'wrongpassword',
    });
    expect(res.statusCode).toBe(401);
  });
});

describe('Health check', () => {
  it('returns 200 on /api/v1/health', async () => {
    const res = await request(app).get('/api/v1/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
  });
});
