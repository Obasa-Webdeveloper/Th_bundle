import 'package:go_router/go_router.dart';
import '../../features/onboarding/screens/splash_screen.dart';
import '../../features/onboarding/screens/onboarding_screen.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/register_screen.dart';
import '../../features/home/screens/home_shell.dart';
import '../../features/wallet/screens/wallet_screen.dart';
import '../../features/wallet/screens/fund_wallet_screen.dart';
import '../../features/buy_data/screens/buy_data_screen.dart';

/// Centralized route table. Each feature owns its own screens folder;
/// this file just wires paths -> widgets so navigation stays declarative.
final appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(path: '/splash', builder: (context, state) => const SplashScreen()),
    GoRoute(path: '/onboarding', builder: (context, state) => const OnboardingScreen()),
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
    GoRoute(path: '/home', builder: (context, state) => const HomeShell()),
    GoRoute(path: '/wallet', builder: (context, state) => const WalletScreen()),
    GoRoute(path: '/wallet/fund', builder: (context, state) => const FundWalletScreen()),
    GoRoute(path: '/buy-data', builder: (context, state) => const BuyDataScreen()),
    // Additional routes: buy-airtime, electricity, cable-tv, education,
    // betting, transactions, referral, notifications, support, settings, profile.
  ],
);
