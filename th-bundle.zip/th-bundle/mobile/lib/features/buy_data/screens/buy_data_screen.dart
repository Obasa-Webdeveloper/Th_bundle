import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/network/api_client.dart';

class _DataPlan {
  final String id;
  final String name;
  final String validity;
  final double price;
  const _DataPlan(this.id, this.name, this.validity, this.price);
}

class BuyDataScreen extends StatefulWidget {
  const BuyDataScreen({super.key});

  @override
  State<BuyDataScreen> createState() => _BuyDataScreenState();
}

class _BuyDataScreenState extends State<BuyDataScreen> {
  final _phoneCtrl = TextEditingController();
  String _network = 'MTN';
  _DataPlan? _selectedPlan;
  bool _loading = false;

  final _networks = const ['MTN', 'AIRTEL', 'GLO', '9MOBILE'];

  // Placeholder plans — in production these come from GET /vtu/data/plans?network=
  final _plans = const [
    _DataPlan('p1', '1GB', '30 days', 350),
    _DataPlan('p2', '2GB', '30 days', 650),
    _DataPlan('p3', '5GB', '30 days', 1500),
    _DataPlan('p4', '10GB', '30 days', 2800),
  ];

  Future<void> _purchase() async {
    if (_selectedPlan == null || _phoneCtrl.text.length != 11) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a plan and enter a valid phone number')));
      return;
    }
    setState(() => _loading = true);
    try {
      final res = await ApiClient.instance.dio.post('/vtu/data/purchase', data: {
        'network': _network,
        'plan_id': _selectedPlan!.id,
        'phone': _phoneCtrl.text,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.data['message'] ?? 'Purchase successful')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Purchase failed. Please try again.')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buy Data')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Network', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: _networks.map((n) => ChoiceChip(
                    label: Text(n),
                    selected: _network == n,
                    onSelected: (_) => setState(() => _network = n),
                    selectedColor: AppColors.primaryBlue.withOpacity(0.15),
                  )).toList(),
            ),
            const SizedBox(height: 20),
            const Text('Phone Number', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(hintText: '080XXXXXXXX'),
            ),
            const SizedBox(height: 20),
            const Text('Select a Plan', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _plans.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.5,
              ),
              itemBuilder: (context, i) {
                final plan = _plans[i];
                final selected = _selectedPlan?.id == plan.id;
                return InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => setState(() => _selectedPlan = plan),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: selected ? AppColors.primaryBlue.withOpacity(0.08) : Colors.white,
                      border: Border.all(color: selected ? AppColors.primaryBlue : Colors.grey.shade200),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(plan.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(plan.validity, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        const Spacer(),
                        Text('₦${plan.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primaryBlue)),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 28),
            ElevatedButton(
              onPressed: _loading ? null : _purchase,
              child: _loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Buy Now'),
            ),
          ],
        ),
      ),
    );
  }
}
