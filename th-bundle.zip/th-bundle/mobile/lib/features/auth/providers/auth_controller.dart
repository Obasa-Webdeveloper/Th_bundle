import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../core/network/api_client.dart';

enum AuthStatus { idle, loading, success, error }

class AuthState {
  final AuthStatus status;
  final String? errorMessage;
  const AuthState({this.status = AuthStatus.idle, this.errorMessage});

  AuthState copyWith({AuthStatus? status, String? errorMessage}) =>
      AuthState(status: status ?? this.status, errorMessage: errorMessage);
}

class AuthController extends StateNotifier<AuthState> {
  AuthController() : super(const AuthState());

  final _dio = ApiClient.instance.dio;
  final _storage = const FlutterSecureStorage();

  Future<bool> login(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
      final data = res.data['data'];
      if (data['requires2fa'] == true) {
        state = state.copyWith(status: AuthStatus.idle);
        return false; // caller should navigate to 2FA screen
      }
      await _storage.write(key: 'access_token', value: data['accessToken']);
      await _storage.write(key: 'refresh_token', value: data['refreshToken']);
      state = state.copyWith(status: AuthStatus.success);
      return true;
    } catch (e) {
      state = state.copyWith(status: AuthStatus.error, errorMessage: _extractError(e));
      return false;
    }
  }

  Future<bool> register({
    required String fullName,
    required String email,
    required String phone,
    required String password,
    String? referralCode,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _dio.post('/auth/register', data: {
        'full_name': fullName,
        'email': email,
        'phone': phone,
        'password': password,
        'referral_code': referralCode,
      });
      state = state.copyWith(status: AuthStatus.success);
      return true;
    } catch (e) {
      state = state.copyWith(status: AuthStatus.error, errorMessage: _extractError(e));
      return false;
    }
  }

  String _extractError(Object e) {
    return 'Something went wrong. Please check your details and try again.';
  }
}

final authControllerProvider = StateNotifierProvider<AuthController, AuthState>(
  (ref) => AuthController(),
);
