import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/network/api_client.dart';

class FundWalletScreen extends StatefulWidget {
  const FundWalletScreen({super.key});

  @override
  State<FundWalletScreen> createState() => _FundWalletScreenState();
}

class _FundWalletScreenState extends State<FundWalletScreen> {
  final _amountCtrl = TextEditingController();
  String _selectedGateway = 'paystack';
  bool _loading = false;

  final _gateways = const [
    {'id': 'paystack', 'label': 'Card / Bank (Paystack)', 'icon': Icons.credit_card},
    {'id': 'flutterwave', 'label': 'Card / Bank (Flutterwave)', 'icon': Icons.credit_card},
    {'id': 'monnify', 'label': 'Virtual Account (Monnify)', 'icon': Icons.account_balance},
  ];

  Future<void> _initiateFunding() async {
    final amount = double.tryParse(_amountCtrl.text);
    if (amount == null || amount < 100) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid amount (min ₦100)')));
      return;
    }
    setState(() => _loading = true);
    try {
      final res = await ApiClient.instance.dio.post('/wallet/fund/initiate', data: {
        'amount': amount,
        'gateway': _selectedGateway,
      });
      final checkoutUrl = res.data['data']['authorization_url'] ?? res.data['data']['link'];
      // In production: launch checkoutUrl in an in-app WebView, then call
      // /wallet/fund/verify on return, or rely on the webhook + polling.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Redirecting to checkout: $checkoutUrl')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not start funding. Please try again.')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fund Wallet')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Amount', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(prefixText: '₦ ', hintText: '0.00'),
            ),
            const SizedBox(height: 24),
            const Text('Choose payment method', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            ..._gateways.map((g) => Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: RadioListTile<String>(
                    value: g['id'] as String,
                    groupValue: _selectedGateway,
                    onChanged: (v) => setState(() => _selectedGateway = v!),
                    title: Text(g['label'] as String),
                    secondary: Icon(g['icon'] as IconData, color: AppColors.primaryBlue),
                  ),
                )),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading ? null : _initiateFunding,
              child: _loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Proceed'),
            ),
          ],
        ),
      ),
    );
  }
}
