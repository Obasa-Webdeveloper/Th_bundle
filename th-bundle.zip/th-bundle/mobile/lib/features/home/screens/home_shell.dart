import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import 'home_dashboard.dart';

/// Bottom-nav shell wrapping the app's primary tabs: Home, Wallet,
/// Transactions, and Profile. Buy-data/airtime/bills etc. are pushed
/// as sub-routes from within the Home tab.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tabIndex = 0;

  final _tabs = const [
    HomeDashboard(),
    Center(child: Text('Transactions')), // -> features/transactions/screens/transaction_history_screen.dart
    Center(child: Text('Notifications')), // -> features/notifications/screens/notifications_screen.dart
    Center(child: Text('Profile')), // -> features/profile/screens/profile_screen.dart
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _tabs[_tabIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        indicatorColor: AppColors.primaryBlue.withOpacity(0.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long_rounded), label: 'History'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications_rounded), label: 'Alerts'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}
