import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class _ServiceItem {
  final String label;
  final IconData icon;
  final String? route;
  const _ServiceItem(this.label, this.icon, this.route);
}

class HomeDashboard extends StatelessWidget {
  const HomeDashboard({super.key});

  static const _services = [
    _ServiceItem('Buy Data', Icons.wifi_rounded, '/buy-data'),
    _ServiceItem('Airtime', Icons.phone_android_rounded, null),
    _ServiceItem('Electricity', Icons.bolt_rounded, null),
    _ServiceItem('Cable TV', Icons.tv_rounded, null),
    _ServiceItem('Education', Icons.school_rounded, null),
    _ServiceItem('Betting', Icons.sports_soccer_rounded, null),
    _ServiceItem('Bulk SMS', Icons.sms_rounded, null),
    _ServiceItem('Recharge Print', Icons.print_rounded, null),
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Hi, welcome back 👋', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              CircleAvatar(backgroundColor: AppColors.primaryBlue.withOpacity(0.1), child: const Icon(Icons.person, color: AppColors.primaryBlue)),
            ],
          ),
          const SizedBox(height: 20),

          // Wallet balance card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.primaryBlue, AppColors.accentGreen]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Wallet Balance', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 6),
                const Text('₦0.00', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white)),
                        onPressed: () => context.push('/wallet/fund'),
                        icon: const Icon(Icons.add),
                        label: const Text('Fund Wallet'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white)),
                        onPressed: () => context.push('/wallet'),
                        icon: const Icon(Icons.account_balance_wallet_outlined),
                        label: const Text('Wallet'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          const Text('Services', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _services.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 16,
              crossAxisSpacing: 12,
              childAspectRatio: 0.78,
            ),
            itemBuilder: (context, i) {
              final s = _services[i];
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => s.route != null ? context.push(s.route!) : null,
                child: Column(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: AppColors.primaryBlue.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(s.icon, color: AppColors.primaryBlue),
                    ),
                    const SizedBox(height: 8),
                    Text(s.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
